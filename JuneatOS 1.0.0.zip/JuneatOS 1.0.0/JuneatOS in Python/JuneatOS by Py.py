print("Welcome to Mini JuneatOS! ver.0.0.1")
print("Copyright ⓒ 2018 JUN all rights reserved. ")
print("Are you first the JuneatOS? please typing help!", "\n")
while True:
    ask = input("JuneatOS : ")
    if ask == "help":
        print("_____command list_____")
        print("help")
        print("version\n")
    if ask == "version":
        print("Version of JuneatOS In Python : 0.0.1")
